//
//  CFoo.h
//  BreakPointDemo
//
//  Created by jianquan on 08/02/2017.
//  Copyright © 2017 JoySeeDog. All rights reserved.
//

#ifndef CFoo_h
#define CFoo_h

#include <stdio.h>

#ifdef __cplusplus

extern "C" {
    
#endif

 void cFoo();

#ifdef __cplusplus
    
}

#endif

#endif /* CFoo_h */

