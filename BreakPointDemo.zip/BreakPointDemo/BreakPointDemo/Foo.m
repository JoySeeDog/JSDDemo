//
//  Foo.m
//  BreakPointDemo
//
//  Created by jianquan on 08/02/2017.
//  Copyright © 2017 JoySeeDog. All rights reserved.
//

#import "Foo.h"

@implementation Foo


- (instancetype)init {
    
    if (self = [super init]) {
        
    }
    
    return self;

}

- (void)foo {
    
    NSLog(@"foo is foo");

}

- (void)bar {
    NSLog(@"bar is bar");
}

@end
