//
//  CPlusPlusFoo.hpp
//  BreakPointDemo
//
//  Created by jianquan on 08/02/2017.
//  Copyright © 2017 JoySeeDog. All rights reserved.
//

#ifndef CPlusPlusFoo_hpp
#define CPlusPlusFoo_hpp

#include <stdio.h>

#endif /* CPlusPlusFoo_hpp */

namespace BreakPointDemoNameSpace {
    
    class BreakPointClass {
        
    public:
        void cplusFoo();
        
    };
    
    
    
}
