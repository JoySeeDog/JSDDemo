//
//  CFoo.c
//  BreakPointDemo
//
//  Created by jianquan on 08/02/2017.
//  Copyright © 2017 JoySeeDog. All rights reserved.
//

#include "CFoo.h"

void cFoo() {
    
    printf("this is cFoo");
    
}
