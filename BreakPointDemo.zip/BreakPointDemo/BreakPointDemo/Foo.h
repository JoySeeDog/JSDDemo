//
//  Foo.h
//  BreakPointDemo
//
//  Created by jianquan on 08/02/2017.
//  Copyright © 2017 JoySeeDog. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Foo : NSObject

- (void)foo;

- (void)bar;

@end
