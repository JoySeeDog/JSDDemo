//
//  ViewController.m
//  BreakPointDemo
//
//  Created by jianquan on 08/02/2017.
//  Copyright © 2017 JoySeeDog. All rights reserved.
//

#import "ViewController.h"
#import "Foo.h"
#include "CPlusPlusFoo.hpp"
#include "CFoo.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    int a = 10;
    
    
    Foo *foo = [[Foo alloc] init];
    
    [foo foo];
    
    [foo bar];
    
    a = 100;
    
    //c++代码
    BreakPointDemoNameSpace::BreakPointClass *cplusFoo = new  BreakPointDemoNameSpace::BreakPointClass;
    
    cplusFoo->cplusFoo();
    
    //c代码
    cFoo();
    
    
//    //测试image命令使用，测试image命令再打开
//    NSArray *arr=[[NSArray alloc] initWithObjects:@"1",@"2", nil];
//    NSLog(@"%@",arr[2]);
//    
    
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
