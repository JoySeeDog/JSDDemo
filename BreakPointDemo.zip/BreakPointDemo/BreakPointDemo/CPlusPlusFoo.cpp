//
//  CPlusPlusFoo.cpp
//  BreakPointDemo
//
//  Created by jianquan on 08/02/2017.
//  Copyright © 2017 JoySeeDog. All rights reserved.
//

#include "CPlusPlusFoo.hpp"

using namespace BreakPointDemoNameSpace;

void  BreakPointClass::cplusFoo() {
    
    printf("this is cplusFoo");

}
